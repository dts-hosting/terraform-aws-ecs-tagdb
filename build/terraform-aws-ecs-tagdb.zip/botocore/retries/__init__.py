"""New retry v2 handlers.

This package obsoletes the botocore/retryhandler.py module and contains
new retry logic.

"""
